Make sure you have the simpleai library installed. If not, you can install it by running pip install simpleai in your command line.
Save the provided script to a local file in your computer, for example "tsp.py"
Open your command line and navigate to the directory where the file is saved.
Run the script by typing python tsp.py and press enter.
The script should execute and print the optimal path and cost.
You can change the matrix and initial state values in the script to test different TSP problems.
Once you are done testing, you can exit the script by pressing ctrl + c
Note: The script is not complete as it is not visiting all the nodes but it will give you an optimal path from the initial node to the last node.